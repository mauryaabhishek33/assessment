package com.demo.assessment.service;

import com.demo.assessment.dto.Agent;
import com.demo.assessment.dto.Issue;
import com.demo.assessment.utils.IssueType;

import java.lang.reflect.Proxy;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CustomerIssueResolutionSystem {

    private Map<Integer, Issue> issueMap;
    private Map<String, Agent> agentMap;
    private Queue<Issue> unassignedIssues;

    private CustomerService customerService;

    private AdminService adminService;
    private AgentService agentService;

    private AssignmentStrategy assignmentStrategy;

     public CustomerIssueResolutionSystem() {
        this.agentMap = new ConcurrentHashMap<>();
        this.issueMap = new ConcurrentHashMap<>();
        this.unassignedIssues = new LinkedList<>();
        adminService = new AdminServiceImpl();
        customerService = new CustomerServiceImpl();
        agentService = new AgentServiceImpl();
        assignmentStrategy = new ExpertiseMatchStrategy();
    }

    public Issue createIssue(String transactionId, IssueType issueType, String subject, String description, String email) {
        Issue issue =  customerService.createIssue(transactionId, issueType, subject, description, email);
        issueMap.put(issue.getIssueId(), issue);
        assignIssue(issue.getIssueId());
        return issue;
    }

    public void addAgent(String agenEmail, String agentName, List<IssueType> expertise) {
         Agent agent = new AdminServiceImpl().addAgent(agenEmail, agentName, expertise);
         agentMap.put(agenEmail,agent);
        processUnassignedIssues();
    }

    private void assignIssue(Integer issueId) {
         Issue issue = issueMap.get(issueId);
         if (issue == null || issue.getResolved()) return;

         for (Agent agent : agentMap.values()) {
             if (agent.canHandleIssue(issue)) {
                 agent.assignIssue(issue);
                 return;
             }
         }
         unassignedIssues.add(issue);
    }


    public List<Issue> getIssues(IssueType issueType) {
         List<Issue> issues = new ArrayList<>();
         for (Issue issue: issueMap.values()) {
             if (issue.getIssueType()==issueType && !issue.getResolved()) {
                 issues.add(issue);
             }
         }
         return issues;
    }

    public void updateIssue(int issueId, String resolution) {
         Issue issue = issueMap.get(issueId);
         if (issue !=null) {
             issue.resolveIssue(resolution);
         }
    }

    public void resolveIssue(int issueId, String resolution) {
         updateIssue(issueId, resolution);
    }

    public void viewAgentWorkHistory(String agentEmail) {
         Agent agent = agentMap.get(agentEmail);
         if (agent!=null) {
             for (Issue issue : agent.getAssignedIssues()) {
                 System.out.println(issue);
             }
         } else {
             System.out.println("Agent not found");
         }
    }

    public void processUnassignedIssues() {
         Iterator<Issue> iterator = unassignedIssues.iterator();
         while(iterator.hasNext()) {
             Issue issue = iterator.next();
             for (Agent agent : agentMap.values()) {
                 if (agent.canHandleIssue(issue)) {
                     agent.assignIssue(issue);
                     iterator.remove();
                     break;
                 }
             }
         }
    }
}
