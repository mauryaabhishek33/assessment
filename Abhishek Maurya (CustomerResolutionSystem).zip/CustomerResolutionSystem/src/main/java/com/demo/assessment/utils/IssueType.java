package com.demo.assessment.utils;

public enum IssueType {
    PAYMENT,
    MUTUAL_FUND,
    GOLD
}
