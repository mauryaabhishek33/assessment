package com.demo.assessment;

import com.demo.assessment.dto.Issue;
import com.demo.assessment.service.CustomerIssueResolutionSystem;
import com.demo.assessment.utils.IssueType;

import java.util.Arrays;
import java.util.List;

public class Solution {
    public static void main(String[] args) {
        System.out.println("Welcome to Customer Resolution System!");
        CustomerIssueResolutionSystem resolutionSystem = new CustomerIssueResolutionSystem();

        //Create agents

        resolutionSystem.addAgent("abc@gmail.com", "Agent 1", Arrays.asList(IssueType.PAYMENT, IssueType.MUTUAL_FUND));
        resolutionSystem.addAgent("abcxyz@gmail.com", "Agent 2", Arrays.asList(IssueType.GOLD,IssueType.MUTUAL_FUND));

        //create issues
        resolutionSystem.createIssue("1", IssueType.PAYMENT, "Payment failed", "Payment failed while upi", "custome@gmail.com");
        resolutionSystem.createIssue("2", IssueType.MUTUAL_FUND, "Payment failed for GOLD", "Payment failed while GOLD fund", "customer3@gmail.com");

        // view agent work history
        resolutionSystem.viewAgentWorkHistory("abc@gmail.com");

        // resolve issue
        resolutionSystem.resolveIssue(2, "refund completed");

        //
        List<Issue> mutualFundIssues = resolutionSystem.getIssues(IssueType.MUTUAL_FUND);
        for (Issue issue: mutualFundIssues) {
            System.out.println(issue);
        }

    }
}