package com.demo.assessment.exception;

import java.security.PrivilegedActionException;

public class CustomerResolutionSystemException extends Exception {

    public CustomerResolutionSystemException() {
    }

    public CustomerResolutionSystemException(String message) {
        super(message);
    }


    public CustomerResolutionSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public CustomerResolutionSystemException(Throwable cause) {
        super(cause);
    }
}
