package com.demo.assessment.service;

import com.demo.assessment.dto.Issue;
import com.demo.assessment.utils.IssueType;

public class CustomerServiceImpl implements  CustomerService {

    @Override
    public Issue createIssue(String transactionId, IssueType issueType, String subject, String description, String email) {
        return Issue.builder().issueType(issueType).subject(subject).transactionId(transactionId)
                .description(description).email(email).build();
    }
}
