package com.demo.assessment.service;

import com.demo.assessment.dto.Issue;
import com.demo.assessment.utils.IssueType;

public interface CustomerService {

    Issue createIssue(String transactionId, IssueType issueType, String subject, String  description, String email);
}
